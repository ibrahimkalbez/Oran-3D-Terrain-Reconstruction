<# Desinstalle l'add-in Revit MCP Bridge (Claude) de toutes les versions de Revit. #>
param([switch]$AllUsers)
$root = if ($AllUsers) { Join-Path $env:ProgramData 'Autodesk\Revit\Addins' } else { Join-Path $env:APPDATA 'Autodesk\Revit\Addins' }
Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
  $addin = Join-Path $_.FullName 'RevitMcpBridge.addin'
  $dir = Join-Path $_.FullName 'RevitMcpBridge'
  if (Test-Path $addin) { Remove-Item $addin -Force; Write-Host "Revit $($_.Name) : manifeste supprime" }
  if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
}
Write-Host "Termine. Fermez Revit avant de desinstaller si un fichier est verrouille."
