@echo off
rem Installe l'add-in Revit MCP Bridge pour Revit 2022-2026 (utilisateur courant).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-RevitMcpBridge.ps1" %*
pause
