<#
  Installe l'add-in Revit MCP Bridge (Claude) pour chaque Revit 2022-2026 present sur ce poste.
  Usage : clic droit > Executer avec PowerShell, ou Installer.cmd.
    -Versions 2024,2025   limiter a certaines versions
    -AllUsers             installer pour tous les utilisateurs (droits administrateur)
#>
param([int[]]$Versions, [switch]$AllUsers)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = if ($AllUsers) { Join-Path $env:ProgramData 'Autodesk\Revit\Addins' } else { Join-Path $env:APPDATA 'Autodesk\Revit\Addins' }

function Test-Revit([int]$v) {
  return (Test-Path "HKLM:\SOFTWARE\Autodesk\Revit\Autodesk Revit $v") -or
         (Test-Path (Join-Path $env:ProgramFiles "Autodesk\Revit $v\Revit.exe")) -or
         (Test-Path (Join-Path $env:ProgramData "Autodesk\Revit\Addins\$v"))
}

if (-not $Versions) { $Versions = 2022..2026 | Where-Object { Test-Revit $_ } }
if (-not $Versions) {
  Write-Host "Aucun Revit 2022-2026 detecte. Indiquez la version : .\Install-RevitMcpBridge.ps1 -Versions 2025" -ForegroundColor Yellow
  exit 1
}

foreach ($v in $Versions) {
  if ($v -lt 2022 -or $v -gt 2026) { Write-Host "Revit $v n'est pas pris en charge (2022-2026)." -ForegroundColor Yellow; continue }
  $build = if ($v -ge 2025) { 'Revit2025-2026' } else { 'Revit2022-2024' }
  $dest = Join-Path $root "$v"
  $dir = Join-Path $dest 'RevitMcpBridge'
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  Copy-Item (Join-Path $here "$build\RevitMcpBridge.dll") $dir -Force
  Copy-Item (Join-Path $here 'RevitMcpBridge.addin') $dest -Force
  Get-ChildItem $dir -Recurse | Unblock-File
  Unblock-File (Join-Path $dest 'RevitMcpBridge.addin')
  Write-Host "Revit $v : add-in installe dans $dest" -ForegroundColor Green
}
Write-Host ""
Write-Host "Redemarrez Revit. Au premier lancement, choisissez 'Toujours charger' pour 'Revit MCP Bridge (Claude)'."
Write-Host "Onglet Complements > MCP Bridge > Claude Bridge affiche l'etat de la passerelle."
